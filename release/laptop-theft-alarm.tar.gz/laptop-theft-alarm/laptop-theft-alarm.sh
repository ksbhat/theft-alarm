#!/bin/bash
# ********************************************* #
# Author: Koustubha Bhat
# Date  : 13 - Sep - 2014
# Vrije Universiteit, Amsterdam
# ********************************************* #

ALARM_FILE="laptop-theft-siren.wav"
SOUND_CARD_ID=1

set_high_vol()
{
  amixer -c 1 sset Master 100%
}

usage()
{
   echo "Laptop theft alarm"
   echo 
   echo "Inspired by the theft of Sony Vaio Laptop of Koustubha Bhat"
   echo "at Vrije Universiteit, Amsterdam, The Netherlands on 8th Sep 2014."
   echo
   echo "#################################################"
   echo "When you want to leave your laptop alone for a while,"
   echo "do:"
   echo "1. run this script ${0} on your terminal"
   echo "2. lock your screen, so that you will have to enter password to enter back"
   echo "Effect:"
   echo "Alarm goes on, if anyone grabs your laptop!"
   echo 
   echo "Take care. Be safe!"
   echo "#################################################"
   echo 
   echo "Options:"
   echo "-test		Lets you test the alarm"
   
   exit 1
}

alarm()
{
  set_high_vol || echo "Coudn't set high volume :("

  if [ $1 -eq 0 ]
  then
	DONTSTOP=1
  else
	DONTSTOP=0
  fi

  count=1
  while [ $count -ge 1 ]
  do
  	aplay ${ALARM_FILE}
	echo $count
	if [ $DONTSTOP -ne 1 ]
	then
		let count--
	fi
  done 
}

enable_alarm()
{
	KEEP_RUNNING=1
	while [ ${KEEP_RUNNING} -eq 1 ]
	do
		BATTERY_STATE=`acpi -a | cut -d: -f 2`
		if [[ "${BATTERY_STATE}" == " off-line" ]]
		then
			echo "Hello buddy! You are about to be caught!!!!!"
			alarm 0
		fi
	done
}

# main
if [ $# -eq 0 ]
then
	enable_alarm
elif [[ "$1" == "-test" ]]
then
	alarm 1
else
	usage
fi	
